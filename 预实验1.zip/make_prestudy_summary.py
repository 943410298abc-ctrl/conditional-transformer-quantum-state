import json, numpy as np, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
out=Path('/mnt/data/nqs_prestudy_results')
R=json.load(open(out/'rbm_1000steps.json'))
trans=[json.load(open(out/f'mini_transformer_seed{k}.json')) for k in [31,32,33]]
ar=[json.load(open(out/f'ar_900steps_seed{k}.json')) for k in [41,45,49]]
fig,ax=plt.subplots(1,2,figsize=(11.5,4.2))
labels=['plain_m4','postproject_plain_m4','project_train_m4','plain_m8']
for mi,m in enumerate(labels):
 for h in [.35,.8]:
  v=[a['fidelity'] for a in R if a['h']==h and a['mode']==m]
  ax[0].errorbar(h+.025*(mi-1.5),np.mean(v),yerr=np.std(v),fmt='o',capsize=2, label=m if h==.35 else None)
ax[0].set(title='Topic 11 | RBM after 1000 updates',xlabel='Transverse field h',ylabel='Ground-state fidelity',ylim=(0.4,1.06));ax[0].legend(fontsize=8)
for entry in trans:
 r=entry['runs'];hs=[a['h'] for a in r]
 f=[a['fidelity'] for a in r];fp=[a['fidelity']/((1+a['parity'])/2) for a in r]
 ax[1].plot(hs,f,'o-',alpha=.65,label='Raw TQS' if entry['seed']==31 else None)
 ax[1].plot(hs,fp,'s--',alpha=.65,label='Post-projected TQS' if entry['seed']==31 else None)
ax[1].set(title='Topic 12 | Mini Transformer, 3 seeds',xlabel='Transverse field h',ylabel='Ground-state fidelity',ylim=(.42,1.05));ax[1].legend(fontsize=8)
plt.tight_layout();plt.savefig(out/'robustness_summary.png',dpi=180);plt.close()

# Formula exact state-symmetry calculation under longitudinal field perturbation
import sys
sys.path.insert(0,'/mnt/data')
from nqs_prestudy import system
fig,ax=plt.subplots(figsize=(6.7,4.1))
for h in [.2,.35,.8]:
 q=[]; lams=np.geomspace(1e-5,.2,55)
 H,z=system(6,h)
 for lam in lams:
  w,U=np.linalg.eigh(H+np.diag(lam*z[:,0]))
  v=U[:,0];q.append((1+float(v@v[::-1]))/2)
 ax.semilogx(lams,q,label=f'h={h}')
ax.set(title='Cost of imposing incorrect parity under longitudinal field',xlabel='Local field |lambda|',ylabel='Fidelity ceiling after parity+ projection')
ax.legend();ax.grid(alpha=.2);plt.tight_layout();plt.savefig(out/'symmetry_breaking_limit.png',dpi=180);plt.close()
# Table mean fields
res={'rbm':{},'transformer':{},'autoregressive':{}}
for h in [.35,.8]:
 for m in labels:
  k=[x for x in R if x['h']==h and x['mode']==m]
  res['rbm'][f'{h}_{m}']={'F_mean':float(np.mean([x['fidelity'] for x in k])),'F_min':float(min(x['fidelity'] for x in k)), 'F_max':float(max(x['fidelity'] for x in k)),'Eerr_mean':float(np.mean([x['energy_err'] for x in k]))}
for h in [.2,.35,.5,.8,1.4]:
 rows=[next(a for a in e['runs'] if a['h']==h) for e in trans]
 res['transformer'][str(h)]={'fidelities':[round(x['fidelity'],5) for x in rows],'projected_fidelities':[round(x['fidelity']/((1+x['parity'])/2),5) for x in rows], 'energy_err':[round(x['energy_err'],6) for x in rows]}
for k,e in zip([41,45,49],ar):res['autoregressive'][str(k)]=e['spearman']
with open(out/'summary.json','w') as f:json.dump(res,f,indent=2,ensure_ascii=False)
