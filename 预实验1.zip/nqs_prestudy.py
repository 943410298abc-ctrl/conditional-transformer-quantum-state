"""CPU-only preliminary research for QML handbook topics 11 and 12.
Not a reproduction of the cited large-system papers. Python 3; numpy scipy torch.
"""
import os, json, time, argparse
import numpy as np
import torch
from scipy.stats import spearmanr
from scipy.linalg import eigh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

torch.set_num_threads(1)
torch.set_default_dtype(torch.float64)
OUT='/mnt/data/nqs_prestudy_results'
os.makedirs(OUT,exist_ok=True)
SCALE=1.0

def system(n,h):
    d=1<<n
    b=np.arange(d)
    signs=1-2*((b[:,None] >> np.arange(n-1,-1,-1)) & 1)
    diag=-np.sum(signs[:,:-1]*signs[:,1:],axis=1).astype(float)
    hmat=np.diag(diag)
    for i in range(n):
        hmat[b,b^(1<<i)]-=h
    return hmat,signs.astype(float)

def obs(n,h,psi,ground=None):
    H, z=system(n,h)
    p=psi**2
    en=float(psi@H@psi)
    E0=float(np.linalg.eigvalsh(H)[0]) if ground is None else float(ground[0])
    cor=float(np.dot(p,z[:,0]*z[:,-1])-np.dot(p,z[:,0])*np.dot(p,z[:,-1]))
    rev=np.arange(len(psi)-1,-1,-1)
    parity=float(np.dot(psi,psi[rev]))
    eigv=np.linalg.eigvalsh(H)
    gap=float(eigv[1]-eigv[0])
    if ground is None:
        E,U=eigh(H); ground=E[0],U[:,0]
    fid=float(abs(ground[1]@psi)**2)
    var=float(np.dot(H@psi,H@psi)-en*en)
    return {'h':float(h),'energy_err':float(en-ground[0]),'fidelity':fid,'correlation':cor,
            'parity':parity,'variance':max(0,var),'gap':gap,'energy':en}

class RBM(torch.nn.Module):
    def __init__(self,n,m,seed):
        super().__init__();torch.manual_seed(seed)
        self.a=torch.nn.Parameter(torch.randn(n)*.04)
        self.b=torch.nn.Parameter(torch.randn(m)*.04)
        self.W=torch.nn.Parameter(torch.randn(m,n)*.04)
    def amplitude(self, s, sym=False):
        # Exact textbook RBM amplitude: exp(a.s) prod_j 2cosh(b_j + W_j.s).
        u=s@self.W.T+self.b
        x=s@self.a + torch.logaddexp(u,-u).sum(axis=1)
        # Stable symmetry projection: Phi(s)+Phi(-s), normalization afterwards
        if sym:
            minus=-s
            v=minus@self.W.T+self.b
            y=minus@self.a+torch.logaddexp(v,-v).sum(axis=1)
            x=torch.logaddexp(x,y)
        return torch.softmax(2*x,dim=0).sqrt()

def rbm_runs(n=8, hs=(.35,.8), steps=350, seeds=(11,22,33)):
    d=1<<n
    _, signs=system(n,hs[0]); s=torch.tensor(signs)
    res=[]; curves={}
    for h in hs:
        H,_=system(n,h); En,U=eigh(H); ground=(En[0],U[:,0]); ht=torch.tensor(H)
        for seed in seeds:
            for mode in ['plain_m4','project_train_m4','plain_m8']:
                torch.manual_seed(seed)
                m=8 if mode=='plain_m8' else 4
                net=RBM(n,m,seed); opt=torch.optim.Adam(net.parameters(),lr=.035)
                hist=[]
                for step in range(steps):
                    opt.zero_grad()
                    p=net.amplitude(s,sym=(mode=='project_train_m4'))
                    E=p@ht@p
                    E.backward();opt.step()
                    if step%10==0 or step==steps-1:hist.append([step,float(E.detach())])
                with torch.no_grad():
                    psi=net.amplitude(s,sym=(mode=='project_train_m4')).numpy()
                    metrics=obs(n,h,psi,ground);metrics.update({'mode':mode,'seed':seed})
                    res.append(metrics)
                    curves[f'{h}_{mode}_{seed}']=hist
                    if mode=='plain_m4':
                        proj=net.amplitude(s,sym=True).numpy()
                        mm=obs(n,h,proj,ground);mm.update({'mode':'postproject_plain_m4','seed':seed})
                        res.append(mm)
    return res,curves

class ConditionalAR(torch.nn.Module):
    """Small exactly normalized autoregressive conditional baseline (not a Transformer)."""
    def __init__(self,n,hidden=32,seed=42):
        super().__init__();self.n=n;torch.manual_seed(seed)
        self.fc=torch.nn.Sequential(torch.nn.Linear(n+n+1,hidden),torch.nn.Tanh(),
                                    torch.nn.Linear(hidden,hidden),torch.nn.Tanh(),torch.nn.Linear(hidden,1))
        self.register_buffer('mask',torch.tril(torch.ones(n,n),diagonal=-1))
        self.register_buffer('ident',torch.eye(n))
    def psi(self,spins,h):
        # spins: [2^N, N], values 0 or 1
        dim=spins.shape[0]
        prefix=spins[:,None,:]*self.mask[None,:,:]
        identity=self.ident[None,:,:].expand(dim,-1,-1)
        ht=torch.ones(dim,self.n,1)*h
        features=torch.cat([prefix,identity,ht],axis=-1)
        logits=self.fc(features).squeeze(-1)
        logp= -torch.nn.functional.softplus(torch.where(spins.bool(),-logits,logits)).sum(dim=1)
        return torch.exp(logp*.5)

def tqs_runs(n=6,steps=400,seed=45):
    vals=np.array([.2,.35,.5,.65,.8,.95,1.1,1.25,1.4])
    train=[.2,.8,1.4]; held=[.35,.5,.65,.95,1.1,1.25]
    d=1<<n
    allbits=((np.arange(d)[:,None] >> np.arange(n-1,-1,-1))&1).astype(float)
    spins=torch.tensor(allbits)
    ground={}; htorch={}
    for h in vals:
        mat,_=system(n,h);E,U=eigh(mat);ground[h]=(E[0],U[:,0]);htorch[h]=torch.tensor(mat)
    net=ConditionalAR(n,32,seed);opt=torch.optim.Adam(net.parameters(),lr=.012)
    training=[]
    for step in range(steps):
        opt.zero_grad();
        E=torch.stack([net.psi(spins,float(h))@htorch[h]@net.psi(spins,float(h)) for h in train]).mean()
        E.backward();opt.step()
        if step%10==0 or step==steps-1: training.append([step,float(E.detach())])
    psis={}
    with torch.no_grad():
        for h in vals:
            psi=net.psi(spins,float(h)).numpy()
            psis[h]=psi
    # Learned-state piecewise interpolation and boundary-hold baseline; no exact target state used
    def lookup(h):
        if h<=train[0]:return psis[train[0]]
        if h>=train[-1]:return psis[train[-1]]
        for lo,hi in zip(train[:-1],train[1:]):
            if lo<=h<=hi:
                w=(h-lo)/(hi-lo)
                amp=(1-w)*psis[lo]+w*psis[hi]
                return amp/np.linalg.norm(amp)
    result=[]
    for h in vals:
        for mode,ps in [('conditional_ar',psis[h]),('learned_state_interpolation',lookup(h))]:
            dat=obs(n,float(h),ps,ground[h]);dat['mode']=mode;dat['split']='train' if h in train else 'heldout';result.append(dat)
    # candidate residual diagnostics for learnt conditional model. finite differences in h and exact <dH/dh>.
    for row in result:
        if row['mode'] != 'conditional_ar':continue
        h=row['h'];eps=1e-3
        with torch.no_grad():
            plus=net.psi(spins,h+eps).numpy();minus=net.psi(spins,h-eps).numpy()
        Ep=plus@system(n,h+eps)[0]@plus
        Em=minus@system(n,h-eps)[0]@minus
        deriv=(Ep-Em)/(2*eps)
        zz=psis[h];dH=(system(n,h+eps)[0]-system(n,h-eps)[0])/(2*eps)
        row['hf_residual']=float(abs(deriv-(zz@dH@zz)))
        row['norm_err']=float(abs(np.linalg.norm(zz)**2-1))
    corr={}
    data=[r for r in result if r['mode']=='conditional_ar' and r['split']=='heldout']
    for ind in ['variance','hf_residual','energy_err']:
        for metric in ['fidelity','correlation']:
            tgt= np.array([1-r['fidelity'] if metric=='fidelity' else abs(r['correlation']-obs(n,r['h'],ground[r['h']][1],ground[r['h']])['correlation']) for r in data])
            pred=np.array([r[ind] for r in data])
            corr[f'{ind}_vs_{metric}']=float(spearmanr(pred,tgt).statistic) if np.std(pred)>1e-12 else None
    return result,training,corr

def plots(rbm,tqs,history):
    fig,ax=plt.subplots(1,2,figsize=(11,4))
    modes=['plain_m4','project_train_m4','postproject_plain_m4','plain_m8']; col=['C0','C1','C2','C3']
    for h in sorted(set(r['h'] for r in rbm)):
        for i,mode in enumerate(modes):
            data=[r for r in rbm if r['h']==h and r['mode']==mode]
            ax[0].scatter([h+.008*(i-1.5)]*len(data),[r['fidelity'] for r in data],label=mode if h==sorted(set(x['h'] for x in rbm))[0] else None, color=col[i],alpha=.8)
    ax[0].set(xlabel='h',ylabel='Ground-state fidelity',title='Topic 11: RBM symmetry and capacity');ax[0].legend(fontsize=7)
    ar=[r for r in tqs if r['mode']=='conditional_ar'];interp=[r for r in tqs if r['mode']!='conditional_ar']
    ax[1].plot([r['h'] for r in ar],[1-r['fidelity'] for r in ar],'o-',label='Conditional autoregressive')
    ax[1].plot([r['h'] for r in interp],[1-r['fidelity'] for r in interp],'s--',label='Interpolation of learned states')
    for h in [.2,.8,1.4]:ax[1].axvline(h,color='gray',alpha=.25)
    ax[1].set(xlabel='h',ylabel='Infidelity (1-F)',title='Topic 12: Conditional generalization');ax[1].legend(fontsize=8)
    plt.tight_layout();plt.savefig(OUT+'/pilot_overview.png',dpi=170);plt.close()
    fig,ax=plt.subplots(1,2,figsize=(11,4))
    for mode in ['plain_m4','project_train_m4','plain_m8']:
        k=f'0.35_{mode}_11'
        if k in history:
            a=np.array(history[k]);ax[0].plot(a[:,0],a[:,1],label=mode)
    ax[0].set(xlabel='Adam update',ylabel='Variational energy',title='RBM optimization at h=0.35');ax[0].legend(fontsize=8)
    ar=[r for r in tqs if r['mode']=='conditional_ar']
    ax[1].plot([r['h'] for r in ar],[r['variance'] for r in ar],'o-',label='Variance')
    ax[1].plot([r['h'] for r in ar],[r['hf_residual'] for r in ar],'s--',label='HF consistency residual')
    ax[1].set(xlabel='h',ylabel='Diagnostic score',title='Topic 12: two non-oracle diagnostics');ax[1].legend(fontsize=8)
    plt.tight_layout();plt.savefig(OUT+'/pilot_diagnostics.png',dpi=170);plt.close()

def main():
    t0=time.time()
    print('Running topic 11 preliminary tests...',flush=True)
    r11,curves=rbm_runs()
    print('Topic11 complete %.1fs'%(time.time()-t0),flush=True)
    print('Running topic 12 preliminary tests...',flush=True)
    r12,training,corr=tqs_runs()
    plots(r11,r12,curves)
    payload={'task11':r11,'task12':r12,'task12_diagnostic_spearman':corr,'task11_curves':curves,'task12_train_curve':training,
         'config':{'N11':8,'h11':[.35,.8],'RBM_steps':350,'RBM_seeds':[11,22,33],
                   'N12':6,'h12_train':[.2,.8,1.4],'cond_AR_steps':400,'cond_AR_seed':45,
                   'disclaimer':'Preliminary limited-seed simulation; conditional autoregressive MLP is NOT the Transformer in handbook.'},
         'seconds':time.time()-t0}
    with open(OUT+'/pilot_results.json','w') as f:json.dump(payload,f,indent=2)
    print('Total seconds:',payload['seconds'],flush=True)
    for h in [.35,.8]:
        print('11 h=',h)
        for m in ['plain_m4','postproject_plain_m4','project_train_m4','plain_m8']:
            o=[x for x in r11 if x['h']==h and x['mode']==m]
            print(m,'fidelity',np.round([x['fidelity'] for x in o],4),'energyerr',np.round([x['energy_err'] for x in o],5))
    print('12 correlation',corr)
    for x in r12:
        if x['split']=='heldout':print(x['mode'],x['h'],'F',round(x['fidelity'],5),'energy err',round(x['energy_err'],5))

if __name__=='__main__':main()
