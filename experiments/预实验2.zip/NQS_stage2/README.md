# Neural Quantum States Research — Stage 2 (CPU reproducible)

## Scope
Two parameter conditional Ising model, 3-seed AR-MLP and Transformer, parity projection and 2D Rayleigh–Ritz checks; physical two-level crossover on N=6,8. Ground truth diagonalization only for evaluation.

## Install
```bash
python -m pip install numpy scipy torch matplotlib scikit-learn
```

## Commands (from extracted directory)
```bash
python run_stage2.py --arch ar --steps 650 --seeds 41 45 49
python run_stage2.py --arch transformer --steps 220 --seeds 31 32 33
python two_level_checks.py
python diagnostic_evaluation.py
```
Outputs are saved into this directory; the included JSONs and PNGs are the actual finished runs.

The accompanying nqs_prestudy.py and tiny_transformer_trial.py are prior baseline modules imported for helper functions. Re-running earlier experiment scripts is not needed.

## Integrity and cautions
- Network training uses six Hamiltonians in [h∈{0.2,0.8,1.4}, lambda∈{0,0.04}]. Never uses ground-state eigenvectors.
- Dense eigensolver uses exact states for **scoring**. Two-level analytical control parameters also use exact low-energy spectra and are not a deployable diagnosis.
- All simulated state vectors are real and positive before projection; symmetry correction may produce signed states.
- AUC is an exploratory ranking on a *fixed hand-picked correlated grid*, not a credible deployment performance estimate.
- The reported figures are not evidence of a newly invented subspace method; see literature section in report.
