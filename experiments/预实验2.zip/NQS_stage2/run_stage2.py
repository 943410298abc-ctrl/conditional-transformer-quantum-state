"""Stage 2: non-oracle, CPU only conditional NQS vs symmetry-breaking parameter.
Ground states are exclusively used for scoring, never training or selecting corrections.
Dense exact enumeration N=6, not a hardware or scalable QMC benchmark.
"""
import os, sys, json, time, argparse
from pathlib import Path
import numpy as np
import torch
from scipy.linalg import eigh
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
from nqs_prestudy import ConditionalAR, system
from tiny_transformer_trial import MiniTQS
np.set_printoptions(precision=8)
torch.set_default_dtype(torch.float64);torch.set_num_threads(1)

def full_h(n,h,lam):
    H,s=system(n,h)
    return H+np.diag(lam*s[:,0]),s

def project_components(psi):
    rev=psi[::-1]
    p=(psi+rev)/2
    m=(psi-rev)/2
    pn=np.linalg.norm(p);mn=np.linalg.norm(m)
    return ((p/pn) if pn>1e-12 else None),((m/mn) if mn>1e-12 else None),pn**2,mn**2

def ritz(H, vectors):
    # Exact Rayleigh-Ritz, orthonormal basis by SVD; drop numerical near-dependence
    candidates=[v for v in vectors if v is not None]
    if not candidates:return None,0
    X=np.stack(candidates,axis=1)
    U,S,_=np.linalg.svd(X,full_matrices=False)
    V=U[:,S>1e-9]
    K=V.T@H@V
    vals,W=eigh(K)
    v=V@W[:,0]
    return v,len(vals)

def metrics(H,psi,exact,n,h,lam,mode,seed,split):
    E0,u,delta=exact
    p=psi**2
    s=((1-2*((np.arange(1<<n)[:,None]>>np.arange(n-1,-1,-1))&1))).astype(float)
    mz=float(p@s[:,0]); zz=float(p@(s[:,0]*s[:,-1])); C=zz-float(p@s[:,0])*float(p@s[:,-1])
    parity=float(psi@psi[::-1]); energy=float(psi@H@psi)
    return dict(seed=seed,n=n,h=h,lam=lam,mode=mode,split=split,F=float(abs(u@psi)**2),
        lossF=float(1-abs(u@psi)**2), Eerr=float(energy-E0), E=float(energy),
        variance=float(np.linalg.norm(H@psi)**2-energy*energy),
        gap=float(delta), parity=parity, mz=mz, C=C, norm=float(np.linalg.norm(psi)**2))

class CondAR2(torch.nn.Module):
    def __init__(self,n,seed,hidden=32):
        super().__init__();torch.manual_seed(seed);self.n=n
        self.net=torch.nn.Sequential(torch.nn.Linear(2*n+2,hidden),torch.nn.Tanh(),
            torch.nn.Linear(hidden,hidden),torch.nn.Tanh(),torch.nn.Linear(hidden,1))
        self.register_buffer('mask',torch.tril(torch.ones(n,n),diagonal=-1))
        self.register_buffer('ident',torch.eye(n))
    def psi(self,spin,h,lam):
        k,n=spin.shape
        prefix=spin[:,None,:]*self.mask[None,:,:]
        iid=self.ident[None,:,:].expand(k,-1,-1)
        params=torch.tensor([h,lam],dtype=spin.dtype).reshape(1,1,2).expand(k,n,-1)
        logits=self.net(torch.cat([prefix,iid,params],dim=-1)).squeeze(-1)
        logprob=(-torch.nn.functional.softplus(torch.where(spin.bool(),-logits,logits))).sum(dim=1)
        return torch.exp(logprob*.5)

class CondTransformer2(MiniTQS):
    def __init__(self,n,seed):
        super().__init__(n,d=16,heads=2,seed=seed)
        self.cond=torch.nn.Linear(2,16)
    def psi(self,spins,h,lam):
        k=spins.shape[0];n=spins.shape[1]
        tokens=torch.cat([torch.full((k,1),2,dtype=torch.long),spins[:,:-1].long()],dim=1)
        positions=torch.arange(n).reshape(1,-1)
        cond=torch.tensor([[h,lam]],dtype=torch.float64)
        hidden=self.embed(tokens)+self.pos(positions)+self.cond(cond).reshape(1,1,-1)
        logits=self.read(self.trans(hidden,mask=self.causal)).squeeze(-1)
        logprob=(-torch.nn.functional.softplus(torch.where(spins.bool(),-logits,logits))).sum(dim=1)
        return torch.exp(logprob*.5)

def calc_psi(model,bits,h,lam):
    return model.psi(bits,h,lam).detach().numpy()

def experiment(arch='ar',seeds=(41,45,49),steps=500,n=6,do_plot=True):
    start=time.monotonic()
    idx=np.arange(1<<n)
    spins=torch.tensor(((idx[:,None]>>np.arange(n-1,-1,-1))&1).astype(float))
    hs_train=[.2,.8,1.4]; lam_train=[0,.04]
    train=[(h,l) for h in hs_train for l in lam_train]
    hs_test=[.2,.35,.8]
    lam_test=[-.04,-.02,-.01,-.003,-.001,-.0001,0,.0001,.0005,.001,.003,.01,.02,.04]
    params=[(h,l) for h in hs_test for l in lam_test]
    ht={p:full_h(n,*p)[0] for p in set(train+params)}
    exact={}
    for p in params:
        E,U=eigh(ht[p]);exact[p]=(E[0],U[:,0],E[1]-E[0])
    ZZ=np.diag(1-2*((idx>>(n-1))&1)).astype(float)
    rows=[]; log=[]
    for seed in seeds:
        mod=CondAR2(n,seed) if arch=='ar' else CondTransformer2(n,seed)
        optim=torch.optim.Adam(mod.parameters(),lr=.012 if arch=='ar' else .009)
        mats={p:torch.tensor(ht[p]) for p in train}
        for it in range(steps):
            optim.zero_grad()
            ev=[]
            for h,l in train:
                w=mod.psi(spins,h,l)
                ev.append(w@mats[(h,l)]@w)
            obj=torch.stack(ev).mean()
            obj.backward();optim.step()
            if it%50==0 or it==steps-1:
                log.append(dict(arch=arch,seed=seed,step=it,obj=float(obj.detach())))
        for h,l in params:
            H=ht[(h,l)]
            psi=calc_psi(mod,spins,h,l)
            plus,minus,qp,qm=project_components(psi)
            split='train' if (h,l) in train else 'heldout'
            corrected={'raw':psi,'hard_plus':plus,
                'known_symmetry_switch':plus if abs(l)<1e-12 else psi}
            v,r=ritz(H,[plus,minus]); corrected['parity_ritz_2d']=v
            v,r=ritz(H,[psi,ZZ@psi]);corrected['localZ_ritz_2d']=v
            if plus is not None:
                v,r=ritz(H,[plus,ZZ@plus]);corrected['symmetric_plus_localZ_ritz_2d']=v
            for name,w in corrected.items():
                if w is not None:
                    m=metrics(H,w,exact[(h,l)],n,h,l,name,seed,split)
                    m['arch']=arch;m['qplus_raw']=qp
                    rows.append(m)
        print('Finished',arch,'seed',seed,'time',round(time.monotonic()-start,1),'sec',flush=True)
    return rows,log,dict(arch=arch,seeds=list(seeds),steps=steps,n=n,train=train,params=params,runtime=time.monotonic()-start,
       torch_version=torch.__version__,np_version=np.__version__)

def aggregate(rows):
    # mean across seeds for each (h,lambda,method)
    d={}
    for r in rows:
        key=(r['arch'],r['h'],r['lam'],r['mode']);d.setdefault(key,[]).append(r)
    out=[]
    for (arch,h,l,m),ss in d.items():
        v={'arch':arch,'h':h,'lam':l,'mode':m,'count':len(ss)}
        for f in ['F','lossF','Eerr','variance','parity','mz','C','qplus_raw']:
            v[f]=float(np.mean([s[f] for s in ss]));v[f+'_sd']=float(np.std([s[f] for s in ss],ddof=1)) if len(ss)>1 else 0.
        out.append(v)
    return out

def fig_plot(agg,path):
    fig,axs=plt.subplots(2,2,figsize=(11.5,8.5))
    methods=['raw','hard_plus','known_symmetry_switch','parity_ritz_2d','symmetric_plus_localZ_ritz_2d']
    tags=['Raw NQS','Hard parity projection','Symmetry-aware switch','2D parity Ritz','2D {plus,Z1 plus} Ritz']
    colors=['#374151','#D95D39','#3678AB','#389C76','#A060BB']
    for k,h in enumerate([.2,.8]):
        ax=axs[0,k]
        for mode,tag,c in zip(methods,tags,colors):
            rr=sorted([a for a in agg if a['h']==h and a['mode']==mode and a['arch']=='ar'],key=lambda x:x['lam'])
            if rr:ax.plot([a['lam'] for a in rr],[a['F'] for a in rr],'.-',label=tag,color=c)
        ax.set(xlabel='Symmetry-breaking field lambda',ylabel='Ground-state fidelity',title=f'h={h} (3 seeds, conditional AR)')
        ax.set_ylim(-.03,1.03);ax.grid(alpha=.2)
    axs[0,1].legend(fontsize=7,loc='lower left')
    for k,h in enumerate([.2,.8]):
        ax=axs[1,k]
        for mode,tag,c in zip(methods,tags,colors):
            rr=sorted([a for a in agg if a['h']==h and a['mode']==mode and a['arch']=='ar'],key=lambda x:x['lam'])
            if rr:ax.plot([a['lam'] for a in rr],[a['Eerr'] for a in rr],'.-',label=tag,color=c)
        ax.set(xlabel='lambda',ylabel='Total variational energy excess',title=f'Energy h={h}')
        ax.grid(alpha=.2)
    fig.suptitle('Stage 2: symmetry mismatch - exact diagonalization only for scoring')
    fig.tight_layout();fig.savefig(path,dpi=165);plt.close(fig)

def main():
    p=argparse.ArgumentParser();p.add_argument('--arch',default='ar',choices=['ar','transformer']);p.add_argument('--steps',type=int,default=None);p.add_argument('--seeds',nargs='+',type=int,default=None);a=p.parse_args()
    seeds=a.seeds or ([41,45,49] if a.arch=='ar' else [31])
    steps=a.steps or (650 if a.arch=='ar' else 220)
    rows,log,metadata=experiment(a.arch,seeds,steps)
    fn=BASE/f'stage2_{a.arch}.json'
    with open(fn,'w') as f:json.dump({'metadata':metadata,'rows':rows,'training':log},f,indent=2)
    if a.arch=='ar':fig_plot(aggregate(rows),BASE/'stage2_main.png')
    for h in [.2,.8]:
        print('=== h',h,'===')
        for l in [0,.001,.01,.04]:
            t=[r for r in rows if r['h']==h and r['lam']==l]
            for mode in ['raw','hard_plus','known_symmetry_switch','parity_ritz_2d','symmetric_plus_localZ_ritz_2d']:
                s=[x for x in t if x['mode']==mode]
                if s:print('lambda',l,mode,'F',round(np.mean([v['F'] for v in s]),5),'Eerr',round(np.mean([v['Eerr'] for v in s]),6))
    print('Wrote',fn)
if __name__=='__main__':main()
