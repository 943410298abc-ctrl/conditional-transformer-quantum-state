"""Rank held-out failures from non-oracle signals. Supervised failure labels only for scoring.
Exact diagonalization must not feed diagnostics nor training.
"""
import json, numpy as np
from pathlib import Path
from sklearn.metrics import roc_auc_score
from scipy.stats import spearmanr
BASE=Path(__file__).resolve().parent
result=[]
for arch in ['ar','transformer']:
 data=json.loads((BASE/f'stage2_{arch}.json').read_text())['rows']
 by={(r['seed'],r['h'],r['lam'],r['mode']):r for r in data}
 samples=[]
 for row in data:
  if row['mode']!='raw' or row['split']!='heldout':continue
  key=(row['seed'],row['h'],row['lam'])
  plus=by[key+('hard_plus',)];ritz=by[key+('parity_ritz_2d',)]
  y=int(row['F']<.9)
  samples.append({'y':y,'h':row['h'],'lam':row['lam'],'F':row['F'],
                  'variance':row['variance'],
                  'parity_defect':max(0,1-row['parity']),
                  'energy_gain_plus':row['E']-plus['E'],
                  'abs_energy_gain_plus':abs(row['E']-plus['E']),
                  'energy_gain_ritz':max(0,row['E']-ritz['E']),
                  'breaking_field_abs':abs(row['lam']),
                  'negative_lambda_indicator':int(row['lam']<0)})
 for score in ['variance','parity_defect','energy_gain_plus','abs_energy_gain_plus','energy_gain_ritz','breaking_field_abs','negative_lambda_indicator']:
  y=np.array([x['y'] for x in samples]);x=np.array([a[score] for a in samples])
  auc=float(roc_auc_score(y,x))
  corr=float(spearmanr(x,1-np.array([a['F'] for a in samples])).statistic)
  result.append(dict(arch=arch,score=score,roc_auc=auc,spearman=corr,points=len(samples),positive=int(y.sum())))
print('Failure label F<0.9, heldout parameter pairs and seeds (not independent samples):')
for arch in ['ar','transformer']:
 print('\n',arch)
 for r in result:
  if r['arch']==arch:print(r['score'],round(r['roc_auc'],3),round(r['spearman'],3))
(BASE/'diagnostics_auc.json').write_text(json.dumps(result,indent=2))
