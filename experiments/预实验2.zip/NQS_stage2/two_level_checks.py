"""Exact finite-size checks of two-level parity mixing. CPU only; all state vectors from ED.
These are physical benchmarks, NOT neural-model performance or non-oracle inference.
"""
import json, numpy as np
from scipy.linalg import eigh
from pathlib import Path
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from run_stage2 import full_h
BASE=Path(__file__).resolve().parent

def ham(n,h,lam,kxx):
 H,s=full_h(n,h,lam)
 if kxx:
  b=np.arange(1<<n)
  for i in range(n-1):
   H[b,b^((1<<i)|(1<<(i+1)))]-=kxx
 return H

def run():
 ls=np.array([0,1e-6,1e-5,3e-5,1e-4,3e-4,1e-3,3e-3,1e-2,3e-2,1e-1]);arr=[]
 for n,kxx in [(6,0),(8,0),(6,.2)]:
  for h in [.2,.35,.8]:
   H=ham(n,h,0,kxx)
   E,U=eigh(H)
   p=np.arange((1<<n)-1,-1,-1)
   pe=np.array([U[:,i]@U[p,i] for i in range(4)])
   # find ground + and first - eigenstate; enforce sectors from parity expectation
   ip=next(i for i in range(len(E)) if U[:,i]@U[p,i]>.9)
   im=next(i for i in range(len(E)) if U[:,i]@U[p,i]<-.9)
   gp=U[:,ip]; gm=U[:,im]
   gap=E[im]-E[ip]
   z=np.diag(np.array([1 if (x>>(n-1))&1==0 else -1 for x in range(1<<n)]))
   v=gp@z@gm
   cross=gap/(2*abs(v))
   for lam in ls:
    vals,V=eigh(ham(n,h,float(lam),kxx))
    u=V[:,0];qplus=.5*(1+u@u[p]);pred=.5*(1+gap/np.sqrt(gap**2+4*(lam*v)**2))
    cplus=gp@u;cminus=gm@u
    subspace_weight=float(cplus**2+cminus**2)
    arr.append(dict(n=n,kxx=kxx,h=h,lam=float(lam),gap=float(gap),matrix_element=float(v),crossover=float(cross),
                    r=float(abs(lam)/cross),qplus=float(qplus),pred_qplus=float(pred),
                    abs_error=float(abs(qplus-pred)),subspace_weight=subspace_weight))
 d={'results':arr,'details':'2-level predictions are ground truth informed theoretical calculations, never deployable model diagnostics'}
 (BASE/'two_level_results.json').write_text(json.dumps(d,indent=2))
 fig,axs=plt.subplots(1,2,figsize=(11,4.1))
 colors=['C0','C1','C2']
 for (n,k),sty in [((6,0),'-'),((8,0),'--'),((6,.2),':')]:
  for h,c in zip([.2,.35,.8],colors):
   sub=[x for x in arr if x['n']==n and x['kxx']==k and x['h']==h]
   axs[0].plot([x['r'] for x in sub],[x['qplus'] for x in sub],linestyle=sty,color=c,alpha=.8,label=f'N={n}, Jxx={k}, h={h}')
   axs[1].plot([x['r'] for x in sub],[x['abs_error'] for x in sub],linestyle=sty,color=c)
 for a in axs:a.set_xscale('symlog',linthresh=.01);a.grid(alpha=.2);a.set_xlabel('Reduced field r = |lambda| / lambda_cross')
 axs[0].set_ylabel('Exact ground-state weight q+');axs[0].set_title('Parity crossover across model families')
 axs[1].set_ylabel('Absolute error: exact vs two-level q+');axs[1].set_title('Limit of two-level approximation')
 xs=np.logspace(-2,3,200);axs[0].plot(xs,0.5*(1+1/np.sqrt(1+xs**2)),color='black',linewidth=2,label='2-level prediction')
 axs[0].legend(fontsize=6,ncol=2);fig.tight_layout();fig.savefig(BASE/'two_level_crossover.png',dpi=165);plt.close(fig)
 for (n,k) in [(6,0),(8,0),(6,.2)]:
  for h in [.2,.35,.8]:
   s=[x for x in arr if x['n']==n and x['kxx']==k and x['h']==h]
   print('n',n,'kxx',k,'h',h,'gap',s[0]['gap'],'v',s[0]['matrix_element'],'lambda_cross',s[0]['crossover'],
    'MAXERR r<5',round(max(x['abs_error'] for x in s if x['r']<5),6), 'MIN2weight',round(min(x['subspace_weight'] for x in s),6))
if __name__=='__main__':run()
