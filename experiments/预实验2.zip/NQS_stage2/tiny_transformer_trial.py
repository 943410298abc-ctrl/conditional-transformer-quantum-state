import os
import sys,json,time,numpy as np,torch
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from nqs_prestudy import system,obs,OUT
from scipy.linalg import eigh

torch.set_num_threads(1);torch.set_default_dtype(torch.float64)
class MiniTQS(torch.nn.Module):
 def __init__(self,n,d=16,heads=2,seed=4):
  super().__init__();torch.manual_seed(seed);self.n=n
  self.embed=torch.nn.Embedding(3,d)
  self.pos=torch.nn.Embedding(n,d)
  self.cond=torch.nn.Linear(1,d)
  lay=torch.nn.TransformerEncoderLayer(d_model=d,nhead=heads,dim_feedforward=32,dropout=0.0,batch_first=True,activation='gelu')
  self.trans=torch.nn.TransformerEncoder(lay,num_layers=1,enable_nested_tensor=False)
  self.read=torch.nn.Linear(d,1)
  self.register_buffer('causal',torch.triu(torch.ones(n,n,dtype=torch.bool),diagonal=1))
 def psi(self,spins,h):
  k=spins.shape[0]; n=spins.shape[1]
  tokens=torch.cat([torch.full((k,1),2,dtype=torch.long), spins[:,:-1].long()],dim=1)
  positions=torch.arange(n,device=spins.device).reshape(1,-1)
  hidden=self.embed(tokens)+self.pos(positions)+self.cond(torch.tensor([[h]],dtype=torch.float64)).reshape(1,1,-1)
  logits=self.read(self.trans(hidden,mask=self.causal)).squeeze(-1)
  # logprob Bernoulli(logits), true s=1
  logp=(-torch.nn.functional.softplus(torch.where(spins.bool(),-logits,logits))).sum(dim=1)
  return torch.exp(logp/2)

def main(seed=31,steps=350):
 n=6;d=1<<n;bits=torch.tensor(((np.arange(d)[:,None] >> np.arange(n-1,-1,-1))&1).astype(float))
 tr=[.2,.8,1.4]; test=[.2,.35,.5,.65,.8,.95,1.1,1.25,1.4]
 ht={};g={}
 for h in test:
  H,_=system(n,h);ht[h]=torch.tensor(H);vals,U=eigh(H);g[h]=(vals[0],U[:,0])
 net=MiniTQS(n,seed=seed);op=torch.optim.Adam(net.parameters(),lr=.012)
 tic=time.monotonic()
 for step in range(steps):
  op.zero_grad()
  energies=[]
  for h in tr:
   v=net.psi(bits,h);energies.append(v@ht[h]@v)
  e=torch.stack(energies).mean();e.backward();op.step()
 with torch.no_grad():
  out=[]
  for h in test:
   psi=net.psi(bits,h).numpy()
   z=obs(n,h,psi,g[h]);z.update({'seed':seed,'arch':'mini_transformer','norm_err':abs(np.linalg.norm(psi)**2-1),'split':'train' if h in tr else 'heldout'})
   out.append(z)
 return {'seed':seed,'steps':steps,'params':sum(p.numel() for p in net.parameters()),'runtime':time.monotonic()-tic,'runs':out}
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--seed',type=int,default=31);p.add_argument('--steps',type=int,default=350);a=p.parse_args()
 result=main(a.seed,a.steps)
 with open(f'{OUT}/mini_transformer_seed{a.seed}.json','w') as f:json.dump(result,f,indent=2)
 print('Runtime',result['runtime'],'parameters',result['params'])
 for row in result['runs']:
  print(row['h'],'fidelity',round(row['fidelity'],6),'energy_err',round(row['energy_err'],6),'parity',round(row['parity'],5),'variance',round(row['variance'],5))
